from flask import Flask,render_template,request
import requests
import os

app=Flask(__name__)

apiKey='c7293a69129743bdb461ec8142c156fa'

@app.route('/',methods=['POST','GET'])
def initial():
    return render_template('index.html')

@app.route('/extract',methods=['GET','POST'])
def extract():
    country=request.form['country']
    print(request.form)
    url='http://newsapi.org/v2/top-headlines?'+'country='+country+'&apiKey='+apiKey
    url+='&q='+request.form['q1']
    url+='&q='+request.form['q2']
    links=[]
    img=[]
    r=requests.get(url)
    req=r.json()
    for i in req['articles']:
        links.append(i['url'])
        img.append(i['urlToImage'])

    return render_template('index.html',contents=links,response=req)
    

if(__name__== '__main__'):
    app.run(port=555)
